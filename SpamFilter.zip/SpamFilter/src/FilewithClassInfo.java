import java.util.Map;


public class FilewithClassInfo {
	
	int ClassInfo;
	Map<String,Integer> WordMap;
	
	public FilewithClassInfo(int info,Map<String,Integer> map)
	{
		ClassInfo = info;
		WordMap = map;
	}

}
