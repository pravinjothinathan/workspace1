package sample;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.*;

public class Client {

	private Map<Integer, Integer> accountPortMap = new HashMap<Integer, Integer>();

	public Client(Map<Integer, Integer> accountPortMap) {
		this.accountPortMap = accountPortMap;
	}

	public String getUserInput() {
		Scanner scan = new Scanner(System.in);
		String input = scan.nextLine();
		return input;
	}

	public int getAccountNoFromUserInput(String input) {
		String[] inToken = input.split(" ");
		int accNo = Integer.parseInt(inToken[1]);
		return accNo;
	}

	private void createSocketAndSendData(String userInput, int port) {
		Socket clientSocket = null;
		PrintWriter os = null;
		BufferedReader in = null;
		try {

			clientSocket = new Socket("localhost", port);
			os = new PrintWriter(clientSocket.getOutputStream(), true);
			in = new BufferedReader(new InputStreamReader(
					clientSocket.getInputStream()));

			// send the data
			os.println(userInput);

			// wait for the server
			String serverInput = null;
			while ((serverInput = in.readLine()) != null) {
				System.out.println(serverInput);
			}
			os.flush();
			os.close();
			in.close();
			clientSocket.close();

		} catch (UnknownHostException e) {
			System.err.println("Dont know about Host");
		} catch (IOException e) {
			System.err.println("No IO for host");

		}

	}

	private void startProcessing() {

		while (true) {
			// get user input
			String userInput = getUserInput();

			try {
				// get the accountNo
				int accountNo = getAccountNoFromUserInput(userInput);

				// now get the port . :)
				int port = this.accountPortMap.get(accountNo);

				// do the socket call
				createSocketAndSendData(userInput, port);
			} catch (Exception e) {
				System.err.println("Error occured while processing request: "
						+ userInput + e);
			}
		}

	}

	public static void main(String args[]) throws IOException,
			UnknownHostException {

		
		Client myClient = new Client(ParseFiles.sendMyMap());
		myClient.startProcessing();
	}
}
